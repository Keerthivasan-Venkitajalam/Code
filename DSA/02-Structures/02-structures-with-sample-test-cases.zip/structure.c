/*
 ************ COMPLETE THE FOLLOWING FUNCTIONS AS INSTRUCTED *************
 *********** YOU ARE NOT ALLOWED TO ADD ANY MORE HEADER FILES ************
 ***** REFER THE EXAMPLE PROGRAM GIVEN FOR READING AND WRITING DATA ******
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "structure.h"

/************************************************************************/

/** 
	A function to create a new movie variable,
		and initialize year of release and average rating to 0.
	@return the starting address of the new movie variable
*/
movieQ1* createMovieQ1() {
	//TODO
	return NULL; // Replace the return value here as required
}

/** 
	A function to read the title, year of release 
		and the average rating of a movie,
		and store it as a structure.
	@param m the starting address of the movie variable
*/
void readMovieQ1(movieQ1* m) {
	// Do not use any printf() statements in this function.
	// Allocate space for 50 characters to store the title before reading it.
	//TODO
}

/** 
	A function to print the title, year of release 
		and the average rating of a movie.
	@param m the starting address of the movie variable
*/
void printMovieQ1(movieQ1* m) {
	// See the sample execution given and match the printf() statements exactly with it (including spaces).
	// Note that, 'Rating' value is printed with two decimal places only. 
	//TODO
}

/************************************************************************/

/** 
	A function to create a new movie variable,
		and initialize year and ratings count to 0.
	@return the starting address of the new movie variable
*/
movieQ2* createMovieQ2() {
	//TODO
	return NULL; // Replace the return value here as required
}

/** 
	A function to read the title, year of release, 
		number of ratings and the ratings of a movie,
		and store it as a structure.
	@param m the starting address of the movie variable
*/
void readMovieQ2(movieQ2* m) {
	// Do not use any printf() statements in this function.
	// Allocate enough space to store the ratings before reading it.
	//TODO
}

/** 
	A function to print the title and year of release of a movie.
	@param m the starting address of the movie variable
*/
void printMovieQ2(movieQ2* m) {
	// See the sample execution given and match the printf() statements exactly with it (including spaces).
	// Note that, 'Rating' value is printed with two decimal places only. 
	//TODO
}

/** 
	A function to find the average rating of a movie.
	@param m the starting address of the movie variable
	@return the average rating of the movie
*/
float averageRating(movieQ2* m) {
	//TODO
	return 0; // Replace the return value here as required
}

/************************************************************************/

/** 
	A function to read a date as a string in the format dd-mmm-yyyy,
		extract day, month and year, and store them in a structure variable.
	@return the date
*/
date getDate() {
	date d;
	//TODO
	return d; 
}

/** 
	A function to check whether a given date is a valid date 
		between the years 1900 and 2050 (both included).
	@param d the date
	@return 1 if d is a valid date, 0 otherwise
*/
int isValidDate(date d) {
	//TODO
	return 0; // Replace the return value here as required
}

/** 
	A function to print a given date in the format dd/mm/yyyy.
	@param d the date
*/
void printDate(date d) {
	// Note that, day and month are printed with two places. Example: 01/02/2023 
	//TODO
}

/************************************************************************/

/** 
	A function to create a new movie variable,
		and initialize ratings count to 0.
	@return the starting address of the new movie variable
*/
movieQ4* createMovieQ4() {
	//TODO
	return NULL; // Replace the return value here as required
}

/** 
	A function to read the title, release date, 
		number of ratings and ratings of a movie,
		and store it as a structure.
	@param m the starting address of the movie variable
*/
void readMovieQ4(movieQ4* m) {
	// Do not use any printf() statements in this function.
	// Use getDate() function to read the release date.
	//TODO
}

/** 
	A function to print the title, release date (in the format dd/mm/yyyy)
		and the ratings of a movie.
	@param m the starting address of the movie variable
*/
void printMovieQ4(movieQ4* m) {
	//See the sample execution given and match the printf() statements exactly with it (including spaces).
	//Note that, ratings are printed with two decimal places only. 
	// Use printDate() function to print the release date.
	//TODO
}

/** 
	A function to check whether a movie is eligible for nominations. 
	@param m the movie
	@return 1 if m is eligible for nominations, 0 otherwise
*/
int isEligible(movieQ4* m) {
	//TODO
	return 0; // Replace the return value here as required
}

/************************************************************************/

/** 
	A function to create a new movie variable,
		and initialize ratings count to 0.
	@return the starting address of the new movie variable
*/
movieQ5* createMovieQ5() {
	//TODO
	return NULL; // Replace the return value here as required
}

/** 
	A function to read the title, release date, 
		number of ratings and ratings of a movie,
		and store it as a structure.
	@param m the starting address of the movie variable
*/
void readMovieQ5(movieQ5* m) {
	// Do not use any printf() statements in this function.
	// Allocate space for 20 characters to store each username before reading it.
	// Note that, username cannot have spaces in between. 
	//TODO
}

/** 
	A function to print the title, 
		release date (in the format dd/mm/yyyy)
		and the ratings (username and rating value) of a movie.
	@param m the starting address of the movie variable
*/
void printMovieQ5(movieQ5* m) {
	//See the sample execution given and match the printf() statements exactly with it (including spaces).
	//Note that, rating values are printed with two decimal places only. 
	//TODO
}

/** 
	A function to find the user who gave the highest rating for a movie.
	@param m the starting address of the movie variable
	@return the username of the user who gave the highest rating for the movie
*/
char* highestRatingUser(movieQ5* m) {
	//TODO
	return NULL; // Replace the return value here as required
}

/************************************************************************/

/** 
	A function to create an array of integers as a structure,
		allocate space for n integers, 
		assign the starting address of the array and the size of the array
		and return the array represented as a structure.
	@param n number of elements in the array
	@return the array represented as a structure
*/
intArray* createIntArray(int n) {
	//TODO
	return NULL; // Replace the return value here as required
}

/** 
	A function to read n integers from the user,
		and store them in an array represented as a structure.
	@param A the array represented as a structure
*/
void readIntArray(intArray* A) {
	// Do not use any printf() statements in this function.
	//TODO
}

/** 
	A function to print the elements in an array represented as a structure.
	The elements should be printed with a single space character 
		separating each element.
	After printing all the elements, add a newline.
	@param A the array represented as a structure
*/
void printIntArray(intArray* A) {
	//See the sample execution given and match the printf() statements exactly with it (including spaces).
	//TODO
}

/************************************************************************/

/** 
	A function to create an array of ratings as a structure,
		allocate space for r ratings (including username and rating value), 
		assign the starting address of the array and the size of the array
		and return the array represented as a structure.
	@param r number of ratings
	@return the rating array represented as a structure
*/
ratingArray* createRatingArray(int r) {
	//TODO
	return NULL; // Replace the return value here as required
}

/** 
	A function to read n ratings from the user,
		and store them in an array represented as a structure.
	@param R the rating array represented as a structure
*/
void readRatingArray(ratingArray* R) {
	// Do not use any printf() statements in this function.
	// Allocate space for 20 characters to store each username before reading it.
	// Note that, username cannot have spaces in between. 
	//TODO
}

/** 
	A function to print the ratings stored in an array represented as a structure.
	@param R the rating array represented as a structure
*/
void printRatingArray(ratingArray* R) {
	//See the sample execution given and match the printf() statements exactly with it (including spaces).
	//Note that, rating values are printed with two decimal places only. 
	//TODO
}

/************************************************************************/

/** 
	A function to create a new movie variable.
	@return the starting address of the new movie variable
*/
movie* createMovie() {
	//TODO
	return NULL; // Replace the return value here as required
}

/** 
	A function to read the title, release date, 
		number of ratings and ratings of a movie,
		and store it as a structure.
	@param m the starting address of the movie variable
*/
void readMovie(movie* m) {
	// Do not use any printf() statements in this function.
	// Use readRatingArray() to read the ratings
	//TODO
}

/** 
	A function to print the details of a movie.
	@param m the starting address of the movie variable
*/
void printMovie(movie* m) {
	//See the sample execution given and match the printf() statements exactly with it (including spaces).
	// Use printRatingArray() to print the ratings
	//TODO
}

/** 
	A function to find the highest rating of a movie.
	@param m the starting address of the movie variable
	@return the highest rating of the movie
*/
rating* highestRating(movie* m) {
	//TODO
	return NULL; // Replace the return value here as required
}

/************************************************************************/

/** 
	A function to create an array of movies as a structure,
		allocate space for n movies, 
		assign the starting address of the array and the size of the array
		and return the array represented as a structure.
	@param n number of movies
	@return the movie array represented as a structure
*/
movieArray* createMovieArray(int n) {
	//TODO
	return NULL; // Replace the return value here as required
}

/** 
	A function to read the details of n movies, 
		and store them in an array represented as a structure.
	@param M the array of movies represented as a structure
*/
void readMovieArray(movieArray* M) {
	// Do not use any printf() statements in this function.
	// Use readMovie() to read the details of a movie
	//TODO
}

/** 
	A function to print the details of movies 
		stored in an array represented as a structure.
	@param M the array of movies represented as a structure
*/
void printMovieArray(movieArray* M) {
	//See the sample execution given and match the printf() statements exactly with it (including spaces).
	// Use printMovie() to print the details of a movie
	//TODO
}

/** 
	A function to print the titles of the movies with average rating above 8.
	Print the titles in separate lines.
	@param M the array of movies represented as a structure
*/
void printMoviesAbove8(movieArray* M) {
	// See the sample execution given and match the printf() statements exactly with it (including spaces).
	// Print the titles in separate lines.
	// Recommended to write a function to find the average rating of a movie
	//TODO
}

/************************************************************************/

/** 
 	A function to create an array of movie pointers as a structure,
		allocate space for n movie pointers, 
		assign the starting address of the array and the size of the array
		and return the array represented as a structure.
	@param n number of movies
	@return the movie pointer array represented as a structure
*/
moviePtrArray* createMoviePointerArray(int n) {
	//TODO
	return NULL; // Replace the return value here as required
}

/** 
	A function to read the details of n movies, and store them in an array 
		of movie pointers represented as a structure.
	@param M the array of movie pointers represented as a structure
*/
void readMoviePointerArray(moviePtrArray* M) {
	// Do not use any printf() statements in this function.
	// Use readMovie() to read the details of a movie
	//TODO

}

/** 
	A function to print the details of movies stored in an array 
		of movie pointers represented as a structure.
	@param M the array of movie pointers represented as a structure
*/
void printMoviePointerArray(moviePtrArray* M) {
	//See the sample execution given and match the printf() statements exactly with it (including spaces).
	// Use printMovie() to print the details of a movie
	//TODO
}

/** 
	A function to print the titles of the movies released after 2000.
	Print the titles in separate lines.
	@param M the array of movies
*/
void printMoviesAfter2000(moviePtrArray* M) {
	//TODO
}

/************************************************************************/
